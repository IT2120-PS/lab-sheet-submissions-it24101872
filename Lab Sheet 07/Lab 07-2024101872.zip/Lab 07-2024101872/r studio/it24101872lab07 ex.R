# Set working directory to your desktop folder named with your registration number
setwd("C:\\Users\\Hp envy\\OneDrive\\Desktop")  # Replace with your actual path

# Probability that train arrives between 8:10 and 8:25 a.m.
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

# Probability that update takes at most 2 hours
pexp(2, rate = 1/3)

# Probability that IQ is above 130
pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)

# IQ score that corresponds to the 95th percentile
qnorm(0.95, mean = 100, sd = 15)
